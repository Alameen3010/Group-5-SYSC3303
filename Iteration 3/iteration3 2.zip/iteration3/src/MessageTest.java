import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class MessageTest {

    @Test
    void getDate() {
        // Test the getDate() method
        Message message = new Message("2024-03-09", 1, "up", 5, false);
        assertEquals("2024-03-09", message.getDate());
    }

    @Test
    void setDate() {
        // Test the setDate() method
        Message message = new Message("2024-03-09", 1, "up", 5, false);
        message.setDate("2024-03-10");
        assertEquals("2024-03-10", message.getDate());
    }

    @Test
    void getSource() {
        // Test the getSource() method
        Message message = new Message("2024-03-09", 1, "up", 5, false);
        assertEquals(1, message.getSource());
    }

    @Test
    void setSource() {
        // Test the setSource() method
        Message message = new Message("2024-03-09", 1, "up", 5, false);
        message.setSource(2);
        assertEquals(2, message.getSource());
    }

    @Test
    void getDirection() {
        // Test the getDirection() method
        Message message = new Message("2024-03-09", 1, "up", 5, false);
        assertEquals("up", message.getDirection());
    }

    @Test
    void setDirection() {
        // Test the setDirection() method
        Message message = new Message("2024-03-09", 1, "up", 5, false);
        message.setDirection("down");
        assertEquals("down", message.getDirection());
    }

    @Test
    void getDestination() {
        // Test the getDestination() method
        Message message = new Message("2024-03-09", 1, "up", 5, false);
        assertEquals(5, message.getDestination());
    }

    @Test
    void setDestination() {
        // Test the setDestination() method
        Message message = new Message("2024-03-09", 1, "up", 5, false);
        message.setDestination(6);
        assertEquals(6, message.getDestination());
    }

    @Test
    void getConfirmation() {
        // Test the getConfirmation() method
        Message message = new Message("2024-03-09", 1, "up", 5, false);
        assertFalse(message.getConfirmation());
    }

    @Test
    void setConfirmation() {
        // Test the setConfirmation() method
        Message message = new Message("2024-03-09", 1, "up", 5, false);
        message.setConfirmation(true);
        assertTrue(message.getConfirmation());
    }
}
