import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;
import java.io.ByteArrayInputStream;
import java.io.ObjectInputStream;
import java.io.ByteArrayOutputStream;
import java.io.ObjectOutputStream;
import java.io.IOException;
import java.net.DatagramSocket;
import java.net.DatagramPacket;
import java.net.InetAddress;

class ElevatorTest {

    @Test
    void processSchedulerRequest() {
        // Mocking the Elevator object
        Elevator elevator = new Elevator("localhost", 50000);

        // Test when the elevator is in STOP state and the current floor is the floor requested
        elevator.state = Elevator.State.STOP;
        elevator.setCurrentFloor(3); // Elevator is on floor 3
        elevator.floorRequested = 3; // Passenger requested floor 3
        elevator.destinationFloor = 5; // Destination floor is 5
        boolean result = elevator.processSchedulerRequest();
        assertEquals(Elevator.State.DOOR_OPENING, elevator.state);
        assertFalse(result); // The elevator should be ready for the next floor request

        // Test when the elevator is in STOP state and the current floor is not the floor requested
        elevator.state = Elevator.State.STOP;
        elevator.currentFloor = 2; // Elevator is on floor 2
        elevator.floorRequested = 3; // Passenger requested floor 3
        elevator.destinationFloor = 5; // Destination floor is 5
        result = elevator.processSchedulerRequest();
        assertEquals(Elevator.State.ACCELERATING, elevator.state);

        // Test when the elevator is in DOOR_OPEN state
        elevator.state = Elevator.State.DOOR_OPEN;
        elevator.elevatorHasPassenger = false; // No passenger inside
        result = elevator.processSchedulerRequest();
        assertEquals(Elevator.State.DOOR_CLOSING, elevator.state);

        // Test when the elevator is in DOOR_CLOSED state and current floor is not the destination floor
        elevator.state = Elevator.State.DOOR_CLOSED;
        elevator.currentFloor = 3; // Elevator is on floor 3
        elevator.destinationFloor = 5; // Destination floor is 5
        result = elevator.processSchedulerRequest();
        assertEquals(Elevator.State.ACCELERATING, elevator.state);

        // Test when the elevator is in DOOR_CLOSED state and current floor is the destination floor
        elevator.state = Elevator.State.DOOR_CLOSED;
        elevator.currentFloor = 5; // Elevator is on destination floor 5
        result = elevator.processSchedulerRequest();
        assertEquals(Elevator.State.STOP, elevator.state);
        assertTrue(result); // The elevator should be ready for the next floor request
    }

    @Test
    void closeSocket() {
        // Test the closeSocket() method
        // Create an Elevator object and close its socket, then assert that the socket is closed.
        Elevator elevator = new Elevator("localhost", 50000);
        elevator.closeSocket();
        assertTrue(elevator.getSendReceiveSocket().isClosed());
    }

    @Test
    void getCurrentFloor() {
        // Test the getCurrentFloor() method
        // Create an Elevator object, set its current floor, and then assert that the getCurrentFloor() method returns the correct current floor.
        Elevator elevator = new Elevator("localhost", 50000);
        elevator.setCurrentFloor(5) ; // Set current floor to 5
        assertEquals(5, elevator.getCurrentFloor());
    }


}
