import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class SchedulerTest {

    @Test
    void closeSocket() {
        // Create a Scheduler object
        Scheduler scheduler = new Scheduler();

        // Close the socket
        scheduler.closeSocket();

        // Assert that the socket is closed
        assertTrue(scheduler.socket.isClosed());
    }
}