import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class FloorTest {

    @Test
    void closeSocket() {
        // Create a Floor object
        Floor floor = new Floor("localhost", 50000);

        // Close the socket
        floor.closeSocket();

        // Assert that the socket is closed
        assertTrue(floor.socket.isClosed());
    }
}